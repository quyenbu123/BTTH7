/*
    Cao Đăng Quyền - 2280602676
 */
package Bai1;

import java.util.Scanner;

public class Demo {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        NV nv1=new NVQL();
        NV nv2=new NVNC();
        NV nv3=new NVPV();
        
        while(true){
            System.out.println("\n=============MENU==============");
            System.out.println("1. Nhap 1 nhan vien quan ly: ");
            System.out.println("2. Nhap 1 nhan vien nghien cuu: ");
            System.out.println("3. Nhap 1 nhan vien phuc vu: ");
            System.out.println("4. Xuat 1 nhan vien quan ly: ");
            System.out.println("5. Xuat 1 nhan vien nghien cuu: ");
            System.out.println("6. Xuat 1 nhan vien phuc vu: ");
            System.out.println("0. Thoat");
            System.out.print("Chọn một tùy chọn: ");
            int choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
                case 1:
                    nv1.Nhap();
                    break;
                case 2:
                    nv2.Nhap();
                    break;
                case 3:
                    nv3.Nhap();
                    break;
                case 4:
                    nv1.Xuat();
                    break;
                case 5:
                    nv2.Xuat();
                    break;
                case 6:
                    nv3.Xuat();
                    break;
                case 0:
                    System.out.println("Thoat chuong trinh.");
                    sc.close();
                    System.exit(0);
                default:
                    System.out.println("Lua chon ko hop le: ");
                        
        }
    }
}}
