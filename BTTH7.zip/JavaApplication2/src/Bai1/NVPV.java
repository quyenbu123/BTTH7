/*
    Cao Đăng Quyền - 2280602676
 */
package Bai1;

public class NVPV extends NV {
    @Override
    
    public void Nhap(){
        super.Nhap();
    }

    public NVPV() {
        super();
    }

    public NVPV(String manv, String tennv, String trinhdo, long luongcb) {
        super(manv, tennv, trinhdo, luongcb);
    }

    public NVPV(NV obj) {
        super(obj);
    }
    
    @Override
    public void Xuat() {
        super.Xuat();
    }
    @Override
    public long TinhLuong(){
        return super.luongcb;
    }
}
