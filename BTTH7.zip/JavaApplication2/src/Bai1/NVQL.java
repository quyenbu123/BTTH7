/*
    Cao Đăng Quyền - 2280602676
 */
package Bai1;

import java.util.Scanner;

public class NVQL extends NV {
    private String chuyenmon;
    private long phucapcv;

    public NVQL() {
        super();
    }

    public NVQL(String manv, String tennv, String trinhdo, long luongcb,String chuyenmon, long phucapcv) {
        super(manv, tennv, trinhdo, luongcb);
        this.chuyenmon = chuyenmon;
        this.phucapcv = phucapcv;
    }

    public NVQL(NVQL obj) {
        super(obj);
        this.chuyenmon = obj.chuyenmon;
        this.phucapcv = obj.phucapcv;
    }
    @Override
    public void Nhap(){
        Scanner sc=new Scanner(System.in);
        super.Nhap();
        System.out.print("Nhap chuyen mon: ");
        chuyenmon=sc.nextLine();
        System.out.print("Nhap phu cap cv: ");
        phucapcv=sc.nextLong();
    }

    @Override
    public void Xuat() {
         super.Xuat(); 
         System.out.format(" %10s | %10s |",chuyenmon,phucapcv);
    }
    @Override
    public long TinhLuong(){
        return super.luongcb+phucapcv;
    }
    
    public String getChuyenmon() {
        return chuyenmon;
    }

    public void setChuyenmon(String chuyenmon) {
        this.chuyenmon = chuyenmon;
    }

    public long getPhucapcv() {
        return phucapcv;
    }

    public void setPhucapcv(long phucapcv) {
        this.phucapcv = phucapcv;
    }
    
}
