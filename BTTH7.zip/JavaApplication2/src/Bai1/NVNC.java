/*
    Cao Đăng Quyền - 2280602676
 */
package Bai1;

import java.util.Scanner;

public class NVNC extends NV {
    private String chuyenmon;
    private long phucapdh;

    public NVNC() {
        super();
    }

    public NVNC(String manv, String tennv, String trinhdo, long luongcb,String chuyenmon, long phucapdh) {
        super(manv, tennv, trinhdo, luongcb);
        this.chuyenmon = chuyenmon;
        this.phucapdh = phucapdh;
    }

    @Override
    public void Nhap(){
        Scanner sc=new Scanner(System.in);
        super.Nhap();
        System.out.print("Nhap chuyen mon: ");
        chuyenmon=sc.nextLine();
        System.out.print("Nhap phu cap dh: ");
        phucapdh=sc.nextLong();
    }

    @Override
    public void Xuat() {
        super.Xuat(); 
        System.out.format(" %10s | %10s |",chuyenmon,phucapdh);
    }
    @Override
    public long TinhLuong(){
        return super.luongcb+phucapdh;
    }
    public NVNC(NVNC obj) {
        super(obj);
        this.chuyenmon = obj.chuyenmon;
        this.phucapdh = obj.phucapdh;
    }

    public String getChuyenmon() {
        return chuyenmon;
    }

    public void setChuyenmon(String chuyenmon) {
        this.chuyenmon = chuyenmon;
    }

    public long getPhucapdh() {
        return phucapdh;
    }

    public void setPhucapdh(long phucapdh) {
        this.phucapdh = phucapdh;
    }
    
}
