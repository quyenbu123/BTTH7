/*
    Cao Đăng Quyền - 2280602676
 */
package Bai3;

import java.util.Scanner;

abstract public class NhanVien extends ConNguoi {
    protected long luong;
    private String ngayNhanViec;
    private PhongBanKhoa phongBanKhoa;

    public NhanVien() {
        super();
    }
    
    public NhanVien(String maSo, String ten, int namSinh, long luong, String ngayNhanViec, PhongBanKhoa phongBanKhoa) {
        super(maSo, ten, namSinh);
        this.luong = luong;
        this.ngayNhanViec = ngayNhanViec;
        this.phongBanKhoa = phongBanKhoa;
    }
    public NhanVien(NhanVien obj) {
        super(obj);
        this.luong = obj.luong;
        this.ngayNhanViec = obj.ngayNhanViec;
        this.phongBanKhoa = obj.phongBanKhoa;
    }
    public double getLuong() {
        return luong;
    }
    public void setLuong(long luong) {
        this.luong = luong;
    }
    public String getNgayNhanViec() {
        return ngayNhanViec;
    }
    public void setNgayNhanViec(String ngayNhanViec) {
        this.ngayNhanViec = ngayNhanViec;
    }
    public PhongBanKhoa getPhongBanKhoa() {
        return phongBanKhoa;
    }
    public void setPhongBanKhoa(PhongBanKhoa phongBanKhoa) {
        this.phongBanKhoa = phongBanKhoa;
    }
    @Override
    public void nhapThongTin() {
    	Scanner scanner=new Scanner(System.in);
        super.nhapThongTin();
        System.out.print("Nhập lương: ");
        luong = scanner.nextLong();
        System.out.print("Nhập ngày nhận việc (dd/MM/yyyy): ");
        ngayNhanViec = scanner.nextLine();
        System.out.println("Nhap phong ban khoa: ");
        phongBanKhoa.nhapThongTin();
    }
    @Override
    public String toString() {
        return super.toString() + String.format(" %10s | %10s | %10s |",luong,ngayNhanViec,phongBanKhoa);
    }

}