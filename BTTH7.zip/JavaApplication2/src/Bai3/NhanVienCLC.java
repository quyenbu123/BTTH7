/*
    Cao Đăng Quyền - 2280602676
 */
package Bai3;

import java.util.Scanner;

public abstract class NhanVienCLC extends NhanVien {
    private String trinhDo;
    private String nganh;
    private String noiDaoTao;

    public NhanVienCLC() {
        super();
    }
    
    public NhanVienCLC(String maSo, String ten, int namSinh, long luong, String ngayNhanViec, PhongBanKhoa phongBanKhoa, String trinhDo, String nganh, String noiDaoTao) {
        super(maSo, ten, namSinh, luong, ngayNhanViec, phongBanKhoa);
        this.trinhDo = trinhDo;
        this.nganh = nganh;
        this.noiDaoTao = noiDaoTao;
    }
    public NhanVienCLC(NhanVienCLC obj) {
        super(obj);
        this.trinhDo = obj.trinhDo;
        this.nganh = obj.nganh;
        this.noiDaoTao = obj.noiDaoTao;
    }
    public String getTrinhDo() {
        return trinhDo;
    }
    public void setTrinhDo(String trinhDo) {
        this.trinhDo = trinhDo;
    }
    public String getNganh() {
        return nganh;
    }
    public void setNganh(String nganh) {
        this.nganh = nganh;
    }
    public String getNoiDaoTao() {
        return noiDaoTao;
    }
    public void setNoiDaoTao(String noiDaoTao) {
        this.noiDaoTao = noiDaoTao;
    }
    @Override
    public void nhapThongTin() {
        Scanner scanner =new Scanner(System.in);
        super.nhapThongTin();
        System.out.print("Nhập trình độ: ");
        trinhDo = scanner.nextLine();
        System.out.print("Nhập ngành: ");
        nganh = scanner.nextLine();
        System.out.print("Nhập nơi đào tạo: ");
        noiDaoTao = scanner.nextLine();
    }
    @Override
    public String toString() {
        return super.toString() + String.format(" %10s | %10s | %15s |",trinhDo,nganh,noiDaoTao);
    }

}