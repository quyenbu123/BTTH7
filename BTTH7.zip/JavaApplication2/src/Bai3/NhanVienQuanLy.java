/*
    Cao Đăng Quyền - 2280602676
 */
package Bai3;

import java.util.Scanner;

public class NhanVienQuanLy extends NhanVienCLC {
    private long phuCapCV;

    public NhanVienQuanLy() {
        super();
    }
    
    public NhanVienQuanLy(String maSo, String ten, int namSinh, long luong, String ngayNhanViec, PhongBanKhoa phongBanKhoa, String trinhDo, String nganh, String noiDaoTao, long phuCapCV) {
        super(maSo, ten, namSinh, luong, ngayNhanViec, phongBanKhoa, trinhDo, nganh, noiDaoTao);
        this.phuCapCV = phuCapCV;
    }
    public NhanVienQuanLy(NhanVienQuanLy obj) {
        super(obj);
        this.phuCapCV = obj.phuCapCV;
    }
    public double getPhuCapCV() {
        return phuCapCV;
    }
    public void setPhuCapCV(long phuCapCV) {
        this.phuCapCV = phuCapCV;
    }
    public double getTongLuong() {
        return luong + phuCapCV;
    }
    public void nhapThongTin() {
        Scanner scanner=new Scanner(System.in);
        super.nhapThongTin();
        System.out.print("Nhập phụ cấp công việc: ");
        phuCapCV = scanner.nextLong();
        scanner.nextLine();         
    }
    @Override
    public String toString() {
        return super.toString() + String.format(" %10s |",phuCapCV);
    }
    public long TinhLuong(){
        return luong +phuCapCV;
    }
}