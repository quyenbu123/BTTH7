/*
    Cao Đăng Quyền - 2280602676
 */
package Bai2;

import Bai1.*;
import java.util.*;

public class HOCVIEN {
    ArrayList<NV> ds=new ArrayList<>();
    public void init(){
        //public NVQL(String manv, String tennv, String trinhdo, long luongcb,String chuyenmon, long phucapcv)
        ds.add(new NVQL("QL_98760","Nguyễn Thúy Hằng","Cử nhân",5000,"TN & MT",100));
        ds.add(new NVQL("QL_98764","Lê Kiên Cường", "Cử nhân", 5000,"TN & MT", 150));
        //public NV(String manv, String tennv, String trinhdo, long luongcb)
        ds.add(new NVPV("PV_12345","Trần Văn Trung","6/12",5000));
        ds.add(new NVPV("PV_12348","Huỳnh Mỹ Nữ", "8/12",5000));
        ds.add(new NVPV("PV_12340","Nguyễn Văn Hùng", "9/12", 5000));
        ds.add(new NVPV("PV_12346","Nguyễn Thị Hồng", "5/12", 5000));
        ds.add(new NVPV("PV_12349","Phạm Quốc Thắng", "6/12", 5000));
        ds.add(new NVPV("PV_12341","Nguyễn Trung Thành","9/12",5000));
        ds.add(new NVPV("PV_12344","Võ Mạnh Hùng","9/12",5000));
        //public NVNC(String manv, String tennv, String trinhdo, long luongcb,String chuyenmon, long phucapdh)
        ds.add(new NVNC("NC_44311","Phan Thanh Huấn", "Thạc sỹ", 5000,"Điện tử", 120));
        ds.add(new NVNC("NC_44322","Bùi Thị Thắm Nồng", "Kỹ sư", 5000,"TK mô hình", 180));
    }
    public void them(NV n){
        ds.add(n);
    }
    public void XuatNVQL(){
        long S=0;
        for(NV n:ds)
            if(n instanceof NVQL){
                n.Xuat();
                System.out.format(" %10s |"+n.TinhLuong());
                System.out.println();
                S+=n.TinhLuong();
            }
        System.out.println("Tong luong: "+S);
    }
    public void XuatNVNC(){
        long S=0;
        for(NV n: ds)
            if(n instanceof NVNC){
                n.Xuat();
                System.out.format(" %10s |"+n.TinhLuong());
                System.out.println();
                S+=n.TinhLuong();
            }
        System.out.println("Tong luong: "+S);
    }
    public void XuatNVPV(){
        long S=0;
        for(NV n:ds)
            if(n instanceof NVPV){
                n.Xuat();
                System.out.format(" %10s |"+n.TinhLuong());
                System.out.println();
                S+=n.TinhLuong();
            }
        System.out.println("Tong luong: "+S);
    }
    public void XuatALL(){
        long S=0;
        for(NV n:ds){           
                n.Xuat();
                System.out.format(" %10s |"+n.TinhLuong());
                System.out.println();
                S+=n.TinhLuong();
        }
        System.out.println("Tong luong: "+S);
    }
}
