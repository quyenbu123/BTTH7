/*
    Cao Đăng Quyền - 2280602676
 */
package Bai2;

import Bai1.*;
import java.util.*;

public class Demo2 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        HOCVIEN ds=new HOCVIEN();
        NV nv;
        ds.init();
        
        while(true){
            System.out.println("\n=============MENU==============");
            System.out.println("1. Nhap 1 nhan vien quan ly: ");
            System.out.println("2. Nhap 1 nhan vien nghien cuu: ");
            System.out.println("3. Nhap 1 nhan vien phuc vu: ");
            System.out.println("4. Xuat ds nhan vien quan ly: ");
            System.out.println("5. Xuat ds nhan vien nghien cuu: ");
            System.out.println("6. Xuat ds nhan vien phuc vu: ");
            System.out.println("7. Xuat ds tat ca nhan vien: ");
            System.out.println("0. Thoat");
            System.out.print("Chọn một tùy chọn: ");
            int choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
                case 1:
                    nv=new NVQL();
                    nv.Nhap();
                    ds.them(nv);
                    break;
                case 2:
                    nv=new NVNC();
                    nv.Nhap();
                    ds.them(nv);
                    break;
                case 3:
                    nv=new NVPV();
                    nv.Nhap();
                    ds.them(nv);
                    break;
                case 4:
                    ds.XuatNVQL();
                    break;
                case 5:
                    ds.XuatNVNC();
                    break;
                case 6:
                    ds.XuatNVPV();
                    break;
                case 7:
                    ds.XuatALL();
                    break;
                case 0:
                    System.out.println("Thoat chuong trinh.");
                    sc.close();
                    System.exit(0);
                default:
                    System.out.println("Lua chon ko hop le: ");
                        
        }
    }
}}
